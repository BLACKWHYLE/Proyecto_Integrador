import pygame
import sys
import time
import random

pygame.init()

# Configuracion de  la ventana
ancho = 800
alto = 600
ventana = pygame.display.set_mode((ancho, alto))
pygame.display.set_caption("Laberinto con Pygame")

# Cargar el fondo 
fondo = pygame.image.load("imagenes/desierto.jpg")
fondo = pygame.transform.scale(fondo, (ancho, alto))

blanco = (000, 000, 000)

tamanio_celda = 26

laberinto = [
    [1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1],
    [1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1],
    [1, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 1, 1, 1, 1, 1, 0, 1],
    [1, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 1],
    [1, 0, 1, 0, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 1, 1, 1, 1, 0, 1, 0, 1],
    [1, 0, 1, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 1, 0, 1],
    [1, 0, 1, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 1, 0, 1],
    [1, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 1],
    [1, 1, 1, 0, 1, 1, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1],
    [1, 0, 0, 0, 0, 1, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 1],
    [1, 1, 1, 1, 0, 1, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 1, 1, 1, 0, 1],
    [1, 0, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 1],
    [1, 0, 1, 1, 1, 1, 1, 1, 0, 1, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 1],
    [1, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1],
    [1, 0, 1, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 1, 0, 1],
    [1, 0, 1, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 1, 0, 1],
    [1, 0, 1, 0, 1, 1, 1, 1, 0, 1, 1, 1, 1, 1, 1, 1, 0, 1, 0, 1, 0, 1],
    [1, 0, 1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 1, 0, 1, 0, 1, 0, 1],
    [1, 1, 1, 1, 0, 0, 0, 1, 0, 1, 1, 1, 0, 1, 0, 1, 1, 1, 0, 1, 0, 1],
    [1, 0, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1, 0, 1, 0, 1],
    [1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1]
]

# punto para terminar el nivel
laberinto[18][18] = 2

objetos_por_recoger = 5
objetos_recolectados = 0

for _ in range(objetos_por_recoger):
    fila = random.randint(1, len(laberinto) - 2)
    columna = random.randint(1, len(laberinto[0]) - 2)
    while laberinto[fila][columna] != 0:
        fila = random.randint(1, len(laberinto) - 2)
        columna = random.randint(1, len(laberinto[0]) - 2)
    laberinto[fila][columna] = 3

offset_x = (ancho - len(laberinto[0]) * tamanio_celda) // 2
offset_y = (alto - len(laberinto) * tamanio_celda) // 2

jugador_pos = [1, 1]

tiempo_limite = 300  # 300 segundos
tiempo_inicio = time.time()

fuente = pygame.font.Font(None, 36)
color_texto = (0, 0, 0)
pos_texto_objetos = (10, 10)
pos_texto_tiempo = (10, 50)

def dibujar_laberinto():
    for i in range(len(laberinto)):
        for j in range(len(laberinto[i])):
            if laberinto[i][j] == 1:
                ventana.blit(pared_imagen, (j*tamanio_celda + offset_x, i*tamanio_celda + offset_y))
            elif laberinto[i][j] == 2:
                pygame.draw.rect(ventana, (0, 255, 0), (j*tamanio_celda + offset_x, i*tamanio_celda + offset_y, tamanio_celda, tamanio_celda))
            elif laberinto[i][j] == 3:
                pygame.draw.circle(ventana, (255, 255, 0), (j*tamanio_celda + tamanio_celda//2 + offset_x, i*tamanio_celda + tamanio_celda//2 + offset_y), tamanio_celda//3)

def dibujar_jugador():
    pygame.draw.circle(ventana, (0, 0, 255), (jugador_pos[1]*tamanio_celda + tamanio_celda//2 + offset_x, jugador_pos[0]*tamanio_celda + tamanio_celda//2 + offset_y), tamanio_celda//3)

def mover_jugador(direccion):
    nueva_pos = jugador_pos.copy()
    if direccion == 'arriba':
        nueva_pos[0] -= 1
    elif direccion == 'abajo':
        nueva_pos[0] += 1
    elif direccion == 'izquierda':
        nueva_pos[1] -= 1
    elif direccion == 'derecha':
        nueva_pos[1] += 1
    
    if laberinto[nueva_pos[0]][nueva_pos[1]] != 1:
        jugador_pos[0], jugador_pos[1] = nueva_pos[0], nueva_pos[1]

# Cargar imagen para las paredes
pared_imagen = pygame.image.load("imagenes/Texturamapa.png")
pared_imagen = pygame.transform.scale(pared_imagen, (tamanio_celda, tamanio_celda))

# Cargar y reproducir música de fondo
pygame.mixer.music.load("sonidos/desierto.mp3")
pygame.mixer.music.play(-1)  # "-1" indica que se reproduce en bucle

# Bucle principal del juego
while True:
    tiempo_actual = time.time()
    tiempo_transcurrido = tiempo_actual - tiempo_inicio
    tiempo_restante = max(0, tiempo_limite - tiempo_transcurrido)

    for evento in pygame.event.get():
        if evento.type == pygame.QUIT:
            pygame.quit()
            sys.exit()

        if evento.type == pygame.KEYDOWN:
            if evento.key == pygame.K_UP:
                mover_jugador('arriba')
            elif evento.key == pygame.K_DOWN:
                mover_jugador('abajo')
            elif evento.key == pygame.K_LEFT:
                mover_jugador('izquierda')
            elif evento.key == pygame.K_RIGHT:
                mover_jugador('derecha')

    # Recolectar objetos al pasar sobre ellos
    fila, columna = jugador_pos
    if laberinto[fila][columna] == 3:
        laberinto[fila][columna] = 0
        objetos_recolectados += 1

    # Limpiar la pantalla
    ventana.fill(blanco)

    # Dibujar el fondo
    ventana.blit(fondo, (0, 0))

    # Verificar si el jugador ha llegado a la ubicación final y recolectado todos los objetos
    if laberinto[jugador_pos[0]][jugador_pos[1]] == 2 and objetos_recolectados == objetos_por_recoger:
        font = pygame.font.Font(None, 72)
        texto_completado = font.render("¡Nivel Completado!", True, blanco)
        texto_rect = texto_completado.get_rect(center=(ancho//2, alto//2))
        ventana.blit(texto_completado, texto_rect)
        pygame.display.update()
        time.sleep(2)  # Esperar 2 segundos antes de salir (opcional)
        break

    # Verificar si se ha agotado el tiempo
    if tiempo_restante <= 0:
        font = pygame.font.Font(None, 72)
        texto_agotado = font.render("¡Tiempo Agotado!", True, blanco)
        texto_rect = texto_agotado.get_rect(center=(ancho//2, alto//2))
        ventana.blit(texto_agotado, texto_rect)
        pygame.display.update()
        time.sleep(2)  # Esperar 2 segundos antes de salir (opcional)
        break

    # Dibujar el laberinto, los objetos y el jugador
    dibujar_laberinto()
    dibujar_jugador()

    # Mostrar el tiempo restante y el progreso del jugador
    texto_tiempo = fuente.render(f"Tiempo restante: {int(tiempo_restante)} segundos", True, blanco)
    ventana.blit(texto_tiempo, pos_texto_tiempo)
    texto_objetos = fuente.render(f"Objetos recolectados: {objetos_recolectados}/{objetos_por_recoger}", True, blanco)
    ventana.blit(texto_objetos, pos_texto_objetos)

    pygame.display.update()

# Esperar 2 segundos antes de salir (opcional)
time.sleep(2)

# Salir del juego
pygame.quit()
sys.exit()

