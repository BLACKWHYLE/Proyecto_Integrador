import pygame
import sys

def ejecutar_codigo_fuente():
    exec(open("niveldesi.py").read(), globals())

pygame.init()

ANCHO = 900
ALTO = 600
screen = pygame.display.set_mode((ANCHO, ALTO))
pygame.display.set_caption("GUARDIAN OF THE MAZE")

fondo = pygame.image.load("imagenes/niveles.png")

screen.blit(fondo, (0, 0))

# Cargar y posicionar la nueva imagen
nueva_imagen = pygame.image.load("imagenes/niveldesi.png")
nueva_imagen_rect = nueva_imagen.get_rect()
nueva_imagen_rect.center = (ANCHO // 2, ALTO // 2)

nueva_imagen2 = pygame.image.load("imagenes/nivelciudad.png")
nueva_imagen2_rect = nueva_imagen2.get_rect()
nueva_imagen2_rect.topleft = (100, 112) 

nueva_imagen3 = pygame.image.load("imagenes/nivelplaya.png")
nueva_imagen3_rect = nueva_imagen3.get_rect()
nueva_imagen3_rect.topleft = (400, 101) 


# Cargar y posicionar el título
titulo = pygame.image.load("imagenes/titu.png")
titulo_rect = titulo.get_rect()
titulo_rect.topleft = (225, -100)   # Alinea la parte superior del título con el centro de la ventana

# Cargar y posicionar la imagen de configuración
configuracion = pygame.image.load("imagenes/configuracion.png")
configuracion_rect = configuracion.get_rect()
configuracion_rect.topleft = (570, -190)  # Posición en la esquina superior derecha

# Definir las coordenadas del rectángulo
rectangulo_coords = (400, 300, 100, 50)  # (x, y, ancho, alto)

# Blit y actualizar pantalla
pygame.draw.rect(screen, (0, 0, 0, 0), rectangulo_coords) # Dibuja el rectángulo
screen.blit(nueva_imagen, nueva_imagen_rect)  # Dibuja la imagen
screen.blit(nueva_imagen2, nueva_imagen2_rect)
screen.blit(nueva_imagen3, nueva_imagen3_rect)
screen.blit(titulo, titulo_rect)  # Dibuja el título
screen.blit(configuracion, configuracion_rect)  # Dibuja la imagen de configuración
pygame.display.flip()

inicia = True
while inicia:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            inicia = False
        elif event.type == pygame.MOUSEBUTTONDOWN:
            x, y = event.pos
            if nueva_imagen_rect.collidepoint(x, y):
                ejecutar_codigo_fuente()

pygame.quit()
sys.exit()

