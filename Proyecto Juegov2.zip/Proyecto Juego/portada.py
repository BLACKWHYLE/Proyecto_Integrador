import pygame
import sys

pygame.init()

screen = pygame.display.set_mode((900, 600))
pygame.display.set_caption("GUARDIAN OF THE MAZE")

fondo = pygame.image.load("imagenes/niveles.png")
fondo = pygame.transform.scale(fondo, (900, 600))
titulo = pygame.image.load("imagenes/titulo.png")
titulo = pygame.transform.scale(titulo, (400, 260))
play = pygame.image.load("imagenes/play.png")
play = pygame.transform.scale(play, (250, 290))
salir = pygame.image.load("imagenes/salir.png")
salir = pygame.transform.scale(salir, (500, 300))
posicion_salir = (193, 250)
posicion_play = (310, 120)

screen.blit(fondo, (0, 0))
screen.blit(titulo, (310, 50))
screen.blit(play, posicion_play)
screen.blit(salir, posicion_salir)
pygame.display.flip()
pygame.mixer.music.load("sonidos/menu.mp3")
pygame.mixer.music.play(-1)


ancho_salir, alto_salir = salir.get_size()
limites_clic_salir = pygame.Rect(posicion_salir[0] + (ancho_salir - 50) // 2, posicion_salir[1] + (alto_salir - 50) // 2, 50, 50)


ancho_play, alto_play = play.get_size()
rect_play = pygame.Rect(
    posicion_play[0] + (ancho_play - 150) // 2,
    posicion_play[1] + (alto_play - 50) // 2,
    150,
    50
)

inicia = True

while inicia:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            inicia = False
        elif event.type == pygame.MOUSEBUTTONDOWN:
            x, y = event.pos
            if rect_play.collidepoint(x, y):
                exec(open("Codi_fuente.py").read(), globals())
            elif limites_clic_salir.collidepoint(x, y):
                inicia = False

pygame.quit()
sys.exit()
