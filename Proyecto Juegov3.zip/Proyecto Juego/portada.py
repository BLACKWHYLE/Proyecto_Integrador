import pygame
import sys

def mostrar_subventana():
    subventana = pygame.display.set_mode((900, 600))
    pygame.display.set_caption("Subventana")

    fondo_subventana = pygame.image.load("imagenes/niveles.png")
    fondo_subventana = pygame.transform.scale(fondo_subventana, (900, 600))

    sonido_imagen = pygame.image.load("imagenes/sonido.png")
    sonido_imagen_rect = pygame.Rect(220, 20, sonido_imagen.get_width(), sonido_imagen.get_height())

    factor_reduccion = 4.6  # Factor de reducción para el rectángulo de interacción
    rect_sonido = pygame.Rect(
        sonido_imagen_rect.left + sonido_imagen.get_width() // 2.5,  # Centro horizontal
        sonido_imagen_rect.top + sonido_imagen.get_height() // 2.5,  # Centro vertical
        sonido_imagen.get_width() // factor_reduccion,  # Nuevo ancho
        sonido_imagen.get_height() // factor_reduccion  # Nuevo alto
    )

    salir_imagen = pygame.image.load("imagenes/salir2.png")
    salir_imagen_rect = pygame.Rect(550, 90, salir_imagen.get_width(), salir_imagen.get_height())

    factor_reduccion = 4.6  # Factor de reducción para el rectángulo de interacción
    rect_salir = pygame.Rect(
        salir_imagen_rect.left + salir_imagen.get_width() // 2.5,  # Centro horizontal
        salir_imagen_rect.top + salir_imagen.get_height() // 2.5,  # Centro vertical
        salir_imagen.get_width() // factor_reduccion,  # Nuevo ancho
        salir_imagen.get_height() // factor_reduccion  # Nuevo alto
    )
    
    idioma_imagen = pygame.image.load("imagenes/idioma.png")
    idioma_imagen_rect = idioma_imagen.get_rect(topleft=(100, 90))
    
    pygame.draw.rect(subventana, (0, 0, 0), rect_sonido)
    subventana.blit(sonido_imagen, sonido_imagen_rect)
    pygame.draw.rect(subventana, (0, 0, 0), rect_salir)
    subventana.blit(salir_imagen, salir_imagen_rect)
    subventana.blit(idioma_imagen, idioma_imagen_rect)

    pygame.display.flip()

    while True:
        for evento in pygame.event.get():
            if evento.type == pygame.QUIT:
                pygame.quit()
                sys.exit()

            if evento.type == pygame.MOUSEBUTTONDOWN:
                if rect_sonido.collidepoint(evento.pos):
                    return "sonido"
                elif rect_salir.collidepoint(evento.pos):
                    return "salir"

        subventana.blit(fondo_subventana, (0, 0))
        subventana.blit(sonido_imagen, sonido_imagen_rect)
        subventana.blit(salir_imagen, salir_imagen_rect)
        subventana.blit(idioma_imagen, idioma_imagen_rect)

        pygame.display.update()

def quitar_sonido():
    pygame.mixer.music.stop()  # Detener la reproducción de la música

def cambiar_idioma():
    # Aquí puedes poner el código para cambiar el idioma
    pass


pygame.init()

screen = pygame.display.set_mode((900, 600))
pygame.display.set_caption("GUARDIAN OF THE MAZE")

fondo = pygame.image.load("imagenes/niveles.png")
fondo = pygame.transform.scale(fondo, (900, 600))
titulo = pygame.image.load("imagenes/titulo.png")
titulo = pygame.transform.scale(titulo, (400, 260))
play = pygame.image.load("imagenes/play.png")
play = pygame.transform.scale(play, (250, 290))
salir = pygame.image.load("imagenes/salir.png")
salir = pygame.transform.scale(salir, (500, 300))
configuracion = pygame.image.load("imagenes/configuracion.png")

configuracion_rect = pygame.Rect(570, -190, configuracion.get_width(), configuracion.get_height())

factor_reduccion = 4.6  # Factor de reducción para el rectángulo de interacción
rect_configuracion = pygame.Rect(
    configuracion_rect.left + configuracion.get_width() // 2.5,  # Centro horizontal
    configuracion_rect.top + configuracion.get_height() // 2.5,  # Centro vertical
    configuracion.get_width() // factor_reduccion,  # Nuevo ancho
    configuracion.get_height() // factor_reduccion  # Nuevo alto
)

posicion_salir = (193, 250)
posicion_play = (310, 120)

pygame.mixer.music.load("sonidos/menu.mp3")
pygame.mixer.music.play(-1)

ancho_salir, alto_salir = salir.get_size()
limites_clic_salir = pygame.Rect(posicion_salir[0] + (ancho_salir - 50) // 2, posicion_salir[1] + (alto_salir - 50) // 2, 50, 50)

ancho_play, alto_play = play.get_size()
rect_play = pygame.Rect(
    posicion_play[0] + (ancho_play - 150) // 2,
    posicion_play[1] + (alto_play - 50) // 2,
    150,
    50
)

subventana_abierta = False

while not subventana_abierta:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            pygame.quit()
            sys.exit()
        elif event.type == pygame.MOUSEBUTTONDOWN:
            x, y = event.pos
            if rect_play.collidepoint(x, y):
                exec(open("Codi_fuente.py").read(), globals())
            elif limites_clic_salir.collidepoint(x, y):
                pygame.quit()
                sys.exit()
            elif rect_configuracion.collidepoint(x, y):
                mostrar_subventana()

    screen.blit(fondo, (0, 0))
    screen.blit(titulo, (310, 20))
    screen.blit(play, posicion_play)
    screen.blit(salir, posicion_salir)

    pygame.draw.rect(screen, (0, 0, 0), rect_configuracion)
    screen.blit(configuracion, configuracion_rect)

    pygame.display.flip()

subventana_abierta = True

while subventana_abierta:
    accion = mostrar_subventana()
    if accion == "sonido":
        quitar_sonido()
    elif accion == "salir":
        pygame.quit()
        sys.exit()
    elif accion == "configuracion":
        pass  # Agrega el código para la acción de configuración aquí
